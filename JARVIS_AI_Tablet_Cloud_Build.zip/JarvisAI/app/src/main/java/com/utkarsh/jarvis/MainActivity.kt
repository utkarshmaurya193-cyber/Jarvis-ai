package com.utkarsh.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onRecognized: ((String) -> Unit)? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening()
        else speak("Boss, microphone permission is required for voice commands.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }

        setContent {
            JarvisScreen(
                onListen = { startListening() },
                onCommand = { command -> handleCommand(command) }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
            tts?.setSpeechRate(0.95f)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        val recognizer = speechRecognizer
        if (recognizer == null) {
            speak("Boss, speech recognition is not available on this device.")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { speak("Boss, I could not understand. Please try again.") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        when {
            command.contains("youtube") || command.contains("यूट्यूब") ->
                launchApp("com.google.android.youtube", "YouTube")
            command.contains("whatsapp") || command.contains("व्हाट्सएप") ->
                launchApp("com.whatsapp", "WhatsApp")
            command.contains("chrome") || command.contains("क्रोम") ->
                launchApp("com.android.chrome", "Chrome")
            command.contains("camera") || command.contains("कैमरा") ->
                openIntent(Intent("android.media.action.IMAGE_CAPTURE"), "Camera")
            command.contains("settings") || command.contains("सेटिंग") ->
                openIntent(Intent(android.provider.Settings.ACTION_SETTINGS), "Settings")
            command.contains("time") || command.contains("समय") || command.contains("टाइम") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                speak("Boss, the time is $time")
            }
            command.contains("battery") || command.contains("बैटरी") -> {
                val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = battery?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
                val percent = if (level >= 0) level * 100 / scale else -1
                speak("Boss, battery is $percent percent.")
            }
            command.contains("call ") || command.contains("कॉल") || command.contains("फोन लगाओ") -> {
                val digits = command.filter { it.isDigit() || it == '+' }
                if (digits.length >= 5) {
                    speak("Boss, opening the dialer. Please confirm the number.")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
                } else {
                    speak("Boss, please say the phone number. I will open it in the dialer for your confirmation.")
                }
            }
            command.contains("message") || command.contains("मैसेज") || command.contains("संदेश") -> {
                speak("Boss, opening the messaging app. Please review and send your message.")
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
            }
            command.contains("home") || command.contains("होम") -> {
                speak("Going to home screen, Boss.")
                val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                startActivity(home)
            }
            command.contains("hello") || command.contains("नमस्ते") || command.contains("हेलो") ->
                speak("Hello Boss. I am online and ready to help.")
            else -> speak("Boss, I heard: $raw. This command is not configured yet.")
        }
    }

    private fun launchApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak("Certainly Boss. Opening $label.")
            startActivity(launch)
        } else speak("Boss, $label is not installed on this device.")
    }

    private fun openIntent(intent: Intent, label: String) {
        if (intent.resolveActivity(packageManager) != null) {
            speak("Opening $label, Boss.")
            startActivity(intent)
        } else speak("Boss, $label is not available.")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(onListen: () -> Unit, onCommand: (String) -> Unit) {
    var typedCommand by remember { mutableStateOf("") }
    var lastCommand by remember { mutableStateOf("At your service, Boss.") }
    val background = Brush.verticalGradient(listOf(Color(0xFF020817), Color(0xFF071A32), Color(0xFF02050C)))

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF28B8FF),
        background = Color(0xFF020817),
        surface = Color(0xFF0B1D33)
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(background).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("J.A.R.V.I.S.", color = Color(0xFF58C8FF), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("PERSONAL AI SYSTEM", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(26.dp))
                Text("GOOD DAY, BOSS.", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(lastCommand, color = Color(0xFF9ACCEB), fontSize = 14.sp)
            }

            Button(
                onClick = onListen,
                modifier = Modifier.size(190.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF07518A))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎙", fontSize = 46.sp)
                    Text("TALK TO JARVIS", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Type a command, Boss") },
                    singleLine = true
                )
                Button(
                    onClick = {
                        if (typedCommand.isNotBlank()) {
                            lastCommand = typedCommand
                            onCommand(typedCommand)
                            typedCommand = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("EXECUTE COMMAND") }

                Text(
                    "Try: Open YouTube • Open WhatsApp • Time • Battery • Home",
                    color = Color(0xFF91A9BE),
                    fontSize = 11.sp
                )
            }
        }
    }
}
