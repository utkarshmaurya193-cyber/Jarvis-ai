# JARVIS AI - Android starter project

This is a starter Android app with a dark Compose dashboard, speech recognition, spoken replies, and basic intent-based phone commands.

## Build an APK using only an Android tablet

You do not need Android Studio on the tablet. Use GitHub in the tablet browser and GitHub Actions to build the APK in the cloud.

1. Sign in to GitHub in Chrome. Create an account if needed.
2. Download and extract this ZIP using the tablet's My Files app.
3. In GitHub, create a new repository named `JarvisAI`. For this starter, a public repository is the simplest way to use GitHub Actions without consuming private-repository minutes. Do not upload passwords, API keys, or personal data.
4. Open the repository, choose **Add file -> Upload files**, and upload the contents inside the extracted `JarvisAI` folder. Make sure `.github/workflows/android-apk.yml` is included. Commit to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build JARVIS APK** and press **Run workflow**. If Actions are disabled, enable them in the repository's Actions settings.
6. Wait for the workflow to finish with a green check.
7. Open that successful run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Open the APK on your tablet and install it. If Android asks, allow Chrome or My Files to install unknown apps. Only install APKs built from source you trust.

## Build locally in Android Studio

On a computer, open this folder in Android Studio, let Gradle sync, then choose Build -> Build Bundle(s) / APK(s) -> Build APK(s).

## Current voice commands

- YouTube kholo / Open YouTube
- WhatsApp kholo / Open WhatsApp
- Chrome kholo / Open Chrome
- Camera kholo
- Settings kholo
- Time batao
- Battery batao
- Home
- A phone number spoken with a call command opens the dialer for confirmation
- Message command opens the default messaging app

## Important limitations

This is not yet the full JARVIS system. It does not yet include an online AI backend, contact-name matching, sending WhatsApp messages, always-on wake word, or a screen-off microphone service. A powered-off phone cannot listen. Background microphone use requires a dedicated wake-word engine, a foreground service, visible notification, user opt-in, and device-specific testing.

The current calling and messaging commands open Android's dialer or messaging app for the user to review and confirm; they do not silently place calls or send messages. Android and app policies restrict some forms of automation.
